@echo off
chcp 65001 >nul
echo ========================================
echo    MUSTAFA MIXING Dashboard
echo ========================================
echo.
pip install flask flask-cors -q
echo.
echo Starting dashboard...
echo Open http://localhost:5000 in your browser
echo Press Ctrl+C to stop
echo.
python app.py
pause
