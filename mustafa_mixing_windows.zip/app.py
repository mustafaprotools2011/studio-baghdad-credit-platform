#!/usr/bin/env python3
"""
MUSTAFA MIXING — Web Dashboard v2.0
Flask web app — 13 pages, SQLite-backed, single source of truth.
"""

import os, json, sqlite3
from flask import Flask, render_template_string, request, jsonify, Response
from flask_cors import CORS

BASE = os.path.dirname(os.path.abspath(__file__))
BANNER = r'''
 _____ ___ _____ _____ _____ _   _ _____ ___  _   _  __  __   _
|     |  _|     |     |  _  | | | |   __|_  |/ \ | |/  \|  \ | |
| | | |  _| | | | | | |     | |_| |   __| __| | | |     | | \| |
|_|_|_|_| |_|_|_|_|_|_|__|__|_____|_____|___|_| \_|_|_|_|_|\___|
  ____ ___ ____   ___  ____  _____   _   _ _____ ____
 / ___|_ _|  _ \ / _ \|  _ \| ____| | \ | | ____|  _ \
| |    | || |_) | | | | |_) |  _|   |  \| |  _| | |_) |
| |___ | ||  _ <| |_| |  _ <| |___  | |\  | |___|  _ <
 \____|___|_| \_\\___/|_| \_\_____| |_| \_|_____|_| \_\
'''

DB_PATH = os.path.join(BASE, "mustafa_mixing.db")
app = Flask(__name__)
app.secret_key = os.urandom(16).hex()
# CORS: allow Vue.js frontend from any origin
CORS(app, resources={r"/api/*": {"origins": "*"}})

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def query(sql, params=None):
    conn = get_db()
    cur = conn.execute(sql, params or [])
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows

def q1(sql, params=None):
    rows = query(sql, params)
    return rows[0] if rows else {}

# Helpers for template building
def rp(t, col, label, cls):
    return '<span class=role-pill role-{}>{}</span>'.format(cls, label) if t.get(col) else ''

def bl(lvl):
    return '<span class="badge badge-{}">{}</span>'.format(lvl, lvl)

LAYOUT = '''<!DOCTYPE html>
<html lang=ar dir=rtl>
<head>
<meta charset=UTF-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>MUSTAFA MIXING — {{ t }}</title>
<style>
{% raw %}@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&family=Inter:wght@300;400;600;700&display=swap');
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#0a0a0f;--bg2:#0f0f18;--bg3:#181825;--bg4:#1e1e32;--border:#2a2a3e;--border2:#3a3a50;--text:#e8e8f0;--text2:#9898b8;--text3:#6a6a88;--gold:#d4a843;--gold2:#f5c842;--gold-dim:#a08030;--green:#22c55e;--red:#ef4444;--blue:#3b82f6;--purple:#8b5cf6;--pink:#ec4899;--cyan:#06b6d4}
body{font-family:'Cairo','Inter',-apple-system,sans-serif;background:var(--bg);color:var(--text);display:flex;min-height:100vh;overflow-x:hidden}
/*── Sidebar ──*/
.sidebar{width:240px;background:var(--bg2);border-left:1px solid var(--border);padding:20px 0;flex-shrink:0;overflow-y:auto;z-index:10}
.sidebar-logo{text-align:center;padding:10px 16px 18px;border-bottom:1px solid var(--border);margin-bottom:8px}
.sidebar-logo .logo-icon{font-size:32px;display:block;margin-bottom:2px}
.sidebar-logo h1{font-size:16px;color:var(--gold);letter-spacing:1px;font-weight:900}
.sidebar-logo small{display:block;font-size:10px;color:var(--text3);margin-top:2px;letter-spacing:1px}
.sidebar-logo .gold-line{width:40px;height:2px;background:linear-gradient(90deg,transparent,var(--gold),transparent);margin:6px auto 0;border-radius:2px}
.nav-section{font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:var(--text3);padding:12px 20px 4px;font-weight:600}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 20px;color:var(--text2);text-decoration:none;font-size:13px;transition:.2s;border-right:3px solid transparent}
.nav-item:hover,.nav-item.active{color:var(--text);background:linear-gradient(90deg,transparent,var(--bg4))}
.nav-item.active{border-right-color:var(--gold);color:var(--gold);background:linear-gradient(90deg,transparent,rgba(212,168,67,.1))}
.nav-item .nav-icon{font-size:16px;width:20px;text-align:center}
/*── Main ──*/
.main{flex:1;padding:28px 36px;overflow-x:hidden;max-width:calc(100vw - 240px)}
.page-header{margin-bottom:28px}
.page-title{font-size:28px;font-weight:900;letter-spacing:-.5px;background:linear-gradient(135deg,var(--gold),var(--gold2));-webkit-background-clip:text;-webkit-text-fill-color:transparent;display:inline-block}
.page-subtitle{color:var(--text2);font-size:13px;margin-top:4px;font-weight:300}
/*── Cards ──*/
.card{background:var(--bg3);border:1px solid var(--border);border-radius:12px;padding:20px 24px;margin-bottom:20px;transition:.2s}
.card:hover{border-color:var(--border2)}
.card-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px}
.card-header h3{font-size:12px;color:var(--text3);text-transform:uppercase;letter-spacing:1px;font-weight:600}
.card-header .badge-count{background:var(--bg4);padding:2px 10px;border-radius:20px;font-size:11px;color:var(--text2)}
/*── Stats Grid ──*/
.stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px;margin-bottom:24px}
.stat-card{background:var(--bg3);border:1px solid var(--border);border-radius:12px;padding:16px;text-align:center;transition:.3s;position:relative;overflow:hidden}
.stat-card:hover{border-color:var(--gold-dim);transform:translateY(-2px);box-shadow:0 8px 30px rgba(0,0,0,.3)}
.stat-card .stat-glow{position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:radial-gradient(circle,rgba(212,168,67,.03) 0%,transparent 70%);pointer-events:none}
.stat-card .value{font-size:28px;font-weight:900;color:var(--gold);position:relative}
.stat-card .label{font-size:11px;color:var(--text3);margin-top:4px;position:relative;font-weight:400}
.stat-card .value-icon{font-size:18px;margin-left:4px}
/*── Tables ──*/
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:13px}
th{text-align:right;padding:10px 12px;border-bottom:2px solid var(--border);color:var(--text3);font-size:11px;text-transform:uppercase;letter-spacing:.5px;font-weight:600}
td{padding:10px 12px;border-bottom:1px solid var(--border);color:var(--text);font-weight:300}
tr:hover td{background:rgba(212,168,67,.04)}
tr:last-child td{border-bottom:none}
a{color:var(--gold);text-decoration:none;transition:.2s}
a:hover{color:var(--gold2);text-decoration:none}
/*── Badges ──*/
.badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600;letter-spacing:.3px}
.badge-Verified{background:linear-gradient(135deg,rgba(34,197,94,.15),rgba(34,197,94,.05));color:var(--green);border:1px solid rgba(34,197,94,.25)}
.badge-Likely{background:linear-gradient(135deg,rgba(59,130,246,.15),rgba(59,130,246,.05));color:var(--blue);border:1px solid rgba(59,130,246,.25)}
.badge-Possible{background:linear-gradient(135deg,rgba(212,168,67,.15),rgba(212,168,67,.05));color:var(--gold);border:1px solid rgba(212,168,67,.25)}
.badge-Rejected{background:linear-gradient(135deg,rgba(239,68,68,.15),rgba(239,68,68,.05));color:var(--red);border:1px solid rgba(239,68,68,.25)}
/*── Role Pills ──*/
.role-pill{display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600;background:var(--bg4);border:1px solid var(--border);margin:2px;transition:.2s}
.role-pill:hover{transform:scale(1.05)}
.role-mix{border-color:rgba(59,130,246,.4);color:var(--blue);background:rgba(59,130,246,.08)}
.role-master{border-color:rgba(139,92,246,.4);color:var(--purple);background:rgba(139,92,246,.08)}
.role-arrange{border-color:rgba(34,197,94,.4);color:var(--green);background:rgba(34,197,94,.08)}
.role-compose{border-color:rgba(212,168,67,.4);color:var(--gold);background:rgba(212,168,67,.08)}
.role-produce{border-color:rgba(239,68,68,.4);color:var(--red);background:rgba(239,68,68,.08)}
.role-sound{border-color:rgba(6,182,212,.4);color:var(--cyan);background:rgba(6,182,212,.08)}
/*── Search ──*/
.search-box{display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap}
.search-box input,.search-box select{background:var(--bg4);border:1px solid var(--border);color:var(--text);padding:10px 16px;border-radius:8px;font-size:13px;font-family:'Cairo',sans-serif;transition:.2s;direction:rtl}
.search-box input:focus,.search-box select:focus{outline:none;border-color:var(--gold-dim);box-shadow:0 0 0 3px rgba(212,168,67,.1)}
.search-box input[type=text]{flex:1;min-width:200px}
.search-box input::placeholder{color:var(--text3)}
.search-box button{background:linear-gradient(135deg,var(--gold),var(--gold2));color:#000;border:none;padding:10px 24px;border-radius:8px;font-weight:700;cursor:pointer;transition:.2s;font-size:13px;font-family:'Cairo',sans-serif}
.search-box button:hover{transform:translateY(-1px);box-shadow:0 4px 15px rgba(212,168,67,.3)}
/*── Info rows ──*/
.info-row{display:flex;margin-bottom:8px;padding:4px 0;border-bottom:1px solid rgba(42,42,62,.5)}
.info-row:last-child{border-bottom:none}
.info-label{width:180px;color:var(--text3);font-size:12px;flex-shrink:0;font-weight:600}
.info-value{font-size:13px;color:var(--text)}
/*── Layout helpers ──*/
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:20px}
@media(max-width:900px){.two-col{grid-template-columns:1fr}}
@media(max-width:768px){.sidebar{display:none}.main{max-width:100vw;padding:20px}}
/*── Animated background ──*/
.bg-pattern{position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:0;overflow:hidden}
.bg-pattern .orb{position:absolute;border-radius:50%;filter:blur(80px);opacity:.12}
.bg-pattern .orb1{width:400px;height:400px;background:var(--gold);top:-100px;right:-100px;animation:orbFloat 15s ease-in-out infinite}
.bg-pattern .orb2{width:300px;height:300px;background:var(--blue);bottom:-80px;left:-80px;animation:orbFloat 20s ease-in-out infinite reverse}
@keyframes orbFloat{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(30px,-30px) scale(1.1)}}
{% endraw %}
</style>
</head>
<body>
<div class=bg-pattern><div class="orb orb1"></div><div class="orb orb2"></div></div>
<nav class=sidebar>
<div class=sidebar-logo>
<span class=logo-icon>🎵</span>
<h1>MUSTAFA MIXING</h1>
<small>Credits Intelligence</small>
<div class=gold-line></div>
</div>
<div class=nav-section>Core</div>
{{ nav("overview","<span class=nav-icon>📊</span> Overview") }}
{{ nav("artists","<span class=nav-icon>🎤</span> Artists") }}
{{ nav("tracks","<span class=nav-icon>🎵</span> Tracks") }}
{{ nav("albums","<span class=nav-icon>💿</span> Albums") }}
{{ nav("credits","<span class=nav-icon>📝</span> Credits") }}
<div class=nav-section>Intelligence</div>
{{ nav("search","<span class=nav-icon>🔍</span> Search") }}
{{ nav("statistics","<span class=nav-icon>📈</span> Statistics") }}
{{ nav("reports","<span class=nav-icon>📋</span> Reports") }}
{{ nav("verification","<span class=nav-icon>✅</span> Verification") }}
{{ nav("legal","<span class=nav-icon>⚖️</span> Legal") }}
{{ nav("royalties","<span class=nav-icon>💰</span> Royalties") }}
<div class=nav-section>System</div>
{{ nav("evidence","<span class=nav-icon>📁</span> Evidence") }}
{{ nav("settings","<span class=nav-icon>⚙️</span> Settings") }}
</nav>
<div class=main>
<div class=page-header>
<h1 class=page-title>{{ t }}</h1>
<p class=page-subtitle>{{ st }}</p>
</div>
{{ c }}
</div>
</body>
</html>'''

def page(title, subtitle, content, page_name):
    def nav_item(p, label):
        act = ' active' if p == page_name else ''
        return '<a href="/{}" class="nav-item{}">{}</a>'.format(p, act, label)
    return render_template_string(LAYOUT, t=title, st=subtitle, c=content, nav=nav_item)

# ─── ROUTES ─────────────────────────────────────────────────────────

# ─── API helpers ─────────────────────────────────────────────────────

def api_response(data, status=200):
    """Return JSON response with optional pretty-print support."""
    pretty = request.args.get("pretty", "").lower() in ("1", "true", "yes")
    indent = 2 if pretty else None
    json_str = json.dumps(data, ensure_ascii=False, indent=indent, default=str)
    return Response(
        json_str + "\n",
        status=status,
        mimetype="application/json",
        headers={"Access-Control-Allow-Origin": "*"}
    )

def api_error(message, status=400):
    return api_response({"error": True, "message": message}, status)

# ─── API endpoints ──────────────────────────────────────────────────

@app.route("/api/credits")
def api_credits():
    """GET /api/credits — return all active credits as JSON."""
    limit = request.args.get("limit", 0, type=int)
    offset = request.args.get("offset", 0, type=int)
    sql = """
        SELECT t.*, a.name as artist_name, a.name_arabic as artist_name_arabic
        FROM tracks t
        JOIN artists a ON t.artist_id = a.id
        WHERE t.is_active = 1
        ORDER BY t.release_year DESC, t.title
    """
    if limit:
        sql += " LIMIT ? OFFSET ?"
        rows = query(sql, (limit, offset))
    else:
        rows = query(sql)
    return api_response({
        "count": len(rows),
        "results": rows
    })

@app.route("/api/credits/<int:id>")
def api_credit_detail(id):
    """GET /api/credits/<id> — return a single credit by ID."""
    row = q1("""
        SELECT t.*, a.name as artist_name, a.name_arabic as artist_name_arabic
        FROM tracks t
        JOIN artists a ON t.artist_id = a.id
        WHERE t.id = ?
    """, (id,))
    if not row:
        return api_error("Credit not found", 404)
    # Get additional data
    roles = query("SELECT * FROM roles WHERE track_id=?", (id,))
    collabs = query("SELECT * FROM collaborators WHERE track_id=?", (id,))
    row["roles"] = roles
    row["collaborators"] = collabs
    return api_response(row)

@app.route("/api/stats")
def api_stats():
    """GET /api/stats — return summary statistics."""
    s = q1("""
        SELECT
            COUNT(*) as total_credits,
            COUNT(DISTINCT artist_id) as total_artists,
            COALESCE(SUM(role_mixing), 0) as mixing,
            COALESCE(SUM(role_mastering), 0) as mastering,
            COALESCE(SUM(role_arranging), 0) as arranging,
            COALESCE(SUM(role_composing), 0) as composing,
            COALESCE(SUM(role_producing), 0) as producing,
            COALESCE(SUM(role_sound_engineer), 0) as sound_engineer,
            COALESCE(SUM(role_executive_prod), 0) as executive_production,
            MIN(release_year) as year_min,
            MAX(release_year) as year_max,
            COUNT(CASE WHEN confidence_level='Verified' THEN 1 END) as verified,
            COUNT(CASE WHEN confidence_level='Likely' THEN 1 END) as likely,
            COUNT(CASE WHEN confidence_level='Possible' THEN 1 END) as possible,
            COUNT(CASE WHEN confidence_level='Rejected' THEN 1 END) as rejected
        FROM tracks WHERE is_active=1
    """)
    years = query("""
        SELECT release_year, COUNT(*) as count
        FROM tracks WHERE is_active=1
        GROUP BY release_year ORDER BY release_year
    """)
    platforms = query("""
        SELECT platform, COUNT(*) as count
        FROM tracks WHERE is_active=1 AND platform IS NOT NULL AND platform != ''
        GROUP BY platform ORDER BY count DESC
    """)
    confidence_dist = query("""
        SELECT confidence_level, COUNT(*) as count
        FROM tracks WHERE is_active=1
        GROUP BY confidence_level ORDER BY count DESC
    """)
    return api_response({
        "summary": s,
        "by_year": years,
        "by_platform": platforms,
        "by_confidence": confidence_dist
    })

@app.route("/api/search")
def api_search():
    """GET /api/search?q= — search credits by keyword."""
    q = request.args.get("q", "").strip()
    if not q:
        return api_response({"query": "", "count": 0, "results": []})
    p = "%{}%".format(q)
    results = query("""
        SELECT t.*, a.name as artist_name, a.name_arabic as artist_name_arabic
        FROM tracks t
        JOIN artists a ON t.artist_id = a.id
        WHERE t.is_active=1
          AND (t.title LIKE ? OR a.name LIKE ? OR t.genre LIKE ? OR t.platform LIKE ?
               OR t.country LIKE ? OR t.exact_credit LIKE ? OR t.label LIKE ? OR t.isrc LIKE ?)
        ORDER BY t.release_year DESC
        LIMIT 100
    """, [p] * 8)
    return api_response({
        "query": q,
        "count": len(results),
        "results": results
    })

@app.route("/api/docs")
def api_docs():
    """GET /api/docs — HTML documentation page for the API."""
    html = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>MUSTAFA MIXING — API Documentation</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#0a0a0f;--bg2:#111118;--bg3:#1a1a28;--border:#2a2a3e;--text:#e8e8f0;--text2:#8888aa;--accent:#f5a623;--accent2:#e8961a;--green:#22c55e;--red:#ef4444;--blue:#3b82f6;--purple:#8b5cf6}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:var(--bg);color:var(--text);padding:32px;max-width:900px;margin:0 auto}
h1{font-size:24px;color:var(--accent);margin-bottom:4px}
h2{font-size:18px;color:var(--text);margin:28px 0 12px;padding-bottom:6px;border-bottom:1px solid var(--border)}
h3{font-size:14px;color:var(--accent2);margin:16px 0 6px}
p{font-size:13px;color:var(--text2);line-height:1.6;margin-bottom:12px}
code{background:var(--bg3);padding:2px 6px;border-radius:4px;font-size:12px;color:var(--green);border:1px solid var(--border)}
pre{background:var(--bg3);border:1px solid var(--border);border-radius:6px;padding:14px;overflow-x:auto;font-size:12px;line-height:1.5;margin:8px 0 16px}
pre code{background:transparent;border:none;padding:0;color:var(--text)}
.endpoint{background:var(--bg2);border:1px solid var(--border);border-radius:8px;padding:16px;margin-bottom:12px}
.endpoint .method{display:inline-block;padding:2px 8px;border-radius:4px;font-weight:700;font-size:11px;margin-right:8px;vertical-align:middle}
.method-get{background:var(--blue);color:#fff}
.method-post{background:var(--green);color:#000}
.method-delete{background:var(--red);color:#fff}
.endpoint .path{font-family:monospace;font-size:14px;color:var(--text);vertical-align:middle}
.endpoint .desc{color:var(--text2);font-size:12px;margin-top:6px}
.param-table{width:100%;border-collapse:collapse;font-size:12px;margin-top:8px}
.param-table th{text-align:left;padding:6px 8px;border-bottom:1px solid var(--border);color:var(--text2);font-size:11px}
.param-table td{padding:6px 8px;border-bottom:1px solid var(--border);color:var(--text)}
.tag{display:inline-block;padding:1px 6px;border-radius:3px;font-size:10px;margin:0 4px}
.tag-required{background:var(--red);color:#fff}
.tag-optional{background:var(--bg3);color:var(--text2);border:1px solid var(--border)}
a{color:var(--accent)}
a:hover{text-decoration:underline}
</style>
</head>
<body>
<h1>MUSTAFA MIXING API</h1>
<p>RESTful JSON API for the Mustafa Kamal Credits Intelligence Platform.</p>
<p>Base URL: <code>/api</code> &nbsp;|&nbsp; Pretty-print: append <code>?pretty=1</code> to any endpoint</p>

<h2>Endpoints</h2>

<div class="endpoint">
  <span class="method method-get">GET</span><span class="path">/api/credits</span>
  <div class="desc">Return all active credits as a JSON array.</div>
  <table class="param-table">
    <tr><th>Param</th><th>Type</th><th>Default</th><th>Description</th></tr>
    <tr><td><code>limit</code></td><td><span class="tag tag-optional">optional</span></td><td><em>all</em></td><td>Max results to return</td></tr>
    <tr><td><code>offset</code></td><td><span class="tag tag-optional">optional</span></td><td>0</td><td>Offset for pagination</td></tr>
    <tr><td><code>pretty</code></td><td><span class="tag tag-optional">optional</span></td><td>0</td><td>Pretty-print JSON (1/true/yes)</td></tr>
  </table>
</div>

<div class="endpoint">
  <span class="method method-get">GET</span><span class="path">/api/credits/{id}</span>
  <div class="desc">Return a single credit by its ID, including roles and collaborators.</div>
  <table class="param-table">
    <tr><th>Param</th><th>Type</th><th>Description</th></tr>
    <tr><td><code>id</code></td><td><span class="tag tag-required">required</span></td><td>Numeric track/credit ID</td></tr>
  </table>
</div>

<div class="endpoint">
  <span class="method method-get">GET</span><span class="path">/api/stats</span>
  <div class="desc">Return summary statistics: total counts, breakdowns by role, year, platform, and confidence level.</div>
</div>

<div class="endpoint">
  <span class="method method-get">GET</span><span class="path">/api/search?q=keyword</span>
  <div class="desc">Full-text search across tracks, artists, genres, platforms, countries, credits, labels, and ISRCs.</div>
  <table class="param-table">
    <tr><th>Param</th><th>Type</th><th>Description</th></tr>
    <tr><td><code>q</code></td><td><span class="tag tag-required">required</span></td><td>Search keyword</td></tr>
  </table>
</div>

<h2>Usage Examples</h2>

<h3>cURL</h3>
<pre><code># Get all credits
curl http://localhost:5000/api/credits

# Get a single credit
curl http://localhost:5000/api/credits/1

# Get stats
curl http://localhost:5000/api/stats

# Search
curl 'http://localhost:5000/api/search?q=Mustafa'

# Pretty-print
curl 'http://localhost:5000/api/credits?pretty=1'</code></pre>

<h3>JavaScript (fetch)</h3>
<pre><code>// All credits
const res = await fetch('/api/credits');
const data = await res.json();
console.log(data.count, 'results');

// Single credit
const credit = await (await fetch('/api/credits/1')).json();

// Search
const results = await (await fetch('/api/search?q=Khalid')).json();

// Paginated
const page = await (await fetch('/api/credits?limit=10&offset=0')).json();</code></pre>

<h3>Response Format</h3>
<pre><code>{
  "count": 19,
  "results": [
    {
      "id": 1,
      "title": "...",
      "artist_name": "...",
      "release_year": 2024,
      "role_mixing": 1,
      "role_mastering": 1,
      ...
    }
  ]
}</code></pre>

<h2>CORS</h2>
<p>All <code>/api/*</code> endpoints include <code>Access-Control-Allow-Origin: *</code> headers, making them accessible from any Vue.js frontend or browser-based application.</p>

<h2>Error Handling</h2>
<p>Errors return:</p>
<pre><code>{
  "error": true,
  "message": "Description of what went wrong"
}</code></pre>
<p>HTTP status codes: <code>400</code> (bad request), <code>404</code> (not found).</p>

<hr style="border:none;border-top:1px solid var(--border);margin:24px 0">
<p style="font-size:11px;color:var(--text2)">
  MUSTAFA MIXING — Credits Intelligence Platform &nbsp;|&nbsp; <a href="/">Back to Dashboard</a>
</p>
</body>
</html>"""
    return html, 200, {"Content-Type": "text/html; charset=utf-8"}


@app.route("/")
def overview():
    s = q1("SELECT COUNT(*) as total, COUNT(DISTINCT artist_id) as artists, SUM(role_mixing) as mix, SUM(role_mastering) as master, SUM(role_arranging) as arrange, SUM(role_composing) as compose, SUM(role_producing) as produce, SUM(role_sound_engineer) as sound, SUM(role_executive_prod) as exec_p, MIN(release_year) as yr_min, MAX(release_year) as yr_max, COUNT(CASE WHEN confidence_level='Verified' THEN 1 END) as v, COUNT(CASE WHEN confidence_level='Likely' THEN 1 END) as l, COUNT(CASE WHEN confidence_level='Possible' THEN 1 END) as p FROM tracks WHERE is_active=1")
    recent = query("SELECT t.*, a.name as an FROM tracks t JOIN artists a ON t.artist_id=a.id WHERE t.is_active=1 ORDER BY t.release_year DESC, t.id DESC LIMIT 8")
    sgrid = '<div class=stat-grid>'
    icons = {"Total Credits":"🎵","Artists":"🎤","Mixing":"🎛️","Mastering":"🔊","Arranging":"🎼","Composing":"✍️","Producing":"🎬","Verified":"✅","Years Active":"📅"}
    for label, key in [("Total Credits","total"),("Artists","artists"),("Mixing","mix"),("Mastering","master"),("Arranging","arrange"),("Composing","compose"),("Producing","produce"),("Verified","v"),("Years Active","yr_min")]:
        val = s[key]
        if key == "yr_min":
            val = "{}-{}".format(s["yr_min"], s["yr_max"])
        sgrid += '<div class=stat-card><div class=stat-glow></div><div class=value>{}<span class=value-icon>{}</span></div><div class=label>{}</div></div>'.format(val, icons.get(label,""), label)
    sgrid += '</div>'
    rrows = ''.join('<tr><td><a href=/track/{}>{}</a></td><td>{}</td><td>{}</td><td>{}{}{}</td><td>{}</td></tr>'.format(t['id'],t['title'][:50],t['an'],t['release_year'],rp(t,'role_mixing','Mix','mix'),rp(t,'role_mastering','Master','master'),rp(t,'role_arranging','Arr','arrange'),bl(t['confidence_level'])) for t in recent)
    return page("Overview", "Mustafa Kamal — {} credits, {} artists".format(s['total'], s['artists']), sgrid + '<div class=card><h3>Recent Credits</h3><div class=table-wrap><table><tr><th>Track</th><th>Artist</th><th>Year</th><th>Roles</th><th>Confidence</th></tr>{}</table></div></div>'.format(rrows), "overview")

@app.route("/artists")
def artists():
    a = query("SELECT a.*, COUNT(t.id) as tc, SUM(t.role_mixing) as m, SUM(t.role_mastering) as mast FROM artists a LEFT JOIN tracks t ON a.id=t.artist_id AND t.is_active=1 GROUP BY a.id ORDER BY tc DESC")
    rows = ''.join('<tr><td><a href=/artist/{}>{}</a></td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>'.format(x['id'],x['name'],x['name_arabic'] or '—',x['country'] or '—',x['tc'],x['m'] or 0,x['mast'] or 0) for x in a)
    return page("Artists", "{} unique artists".format(len(a)), '<div class=card><div class=table-wrap><table><tr><th>Artist</th><th>Arabic</th><th>Country</th><th>Tracks</th><th>Mix</th><th>Master</th></tr>{}</table></div></div>'.format(rows), "artists")

@app.route("/tracks")
def tracks():
    t = query("SELECT t.*, a.name as an FROM tracks t JOIN artists a ON t.artist_id=a.id WHERE t.is_active=1 ORDER BY t.release_year DESC, t.title")
    rows = ''.join('<tr><td><a href=/track/{}>{}</a></td><td>{}</td><td>{}</td><td>{}{}{}{}</td><td>{}</td><td>{}</td></tr>'.format(x['id'],x['title'][:60],x['an'],x['release_year'],rp(x,'role_mixing','M','mix'),rp(x,'role_mastering','Mst','master'),rp(x,'role_arranging','A','arrange'),rp(x,'role_composing','C','compose'),x.get('platform','') or '—',bl(x['confidence_level'])) for x in t)
    return page("Tracks", "{} total credits".format(len(t)), '<div class=card><div class=table-wrap><table><tr><th>Track</th><th>Artist</th><th>Year</th><th>Roles</th><th>Platform</th><th>Confidence</th></tr>{}</table></div></div>'.format(rows), "tracks")

@app.route("/track/<int:id>")
def track_detail(id):
    t = q1("SELECT t.*, a.name as an FROM tracks t JOIN artists a ON t.artist_id=a.id WHERE t.id=?", (id,))
    if not t: return "Not found", 404
    roles = query("SELECT * FROM roles WHERE track_id=?", (id,))
    collabs = query("SELECT * FROM collaborators WHERE track_id=?", (id,))
    rpills = ''.join('<span class=role-pill>{}{}</span> '.format(r['role_name'], ' ('+r['role_arabic']+')' if r['role_arabic'] else '') for r in roles) or '<span style=color:var(--text2)>None</span>'
    crows = ''.join('<tr><td>{}</td><td>{}</td></tr>'.format(c['name'],c['role']) for c in collabs) or '<tr><td colspan=2 style=color:var(--text2)>None</td></tr>'
    info = lambda l, v: '<div class=info-row><div class=info-label>{}</div><div class=info-value>{}</div></div>'.format(l, v)
    src_link = '<a href={} target=_blank>{}…</a>'.format(t['source_url'], t['source_url'][:70]) if t['source_url'] else '—'
    html = '<div class=card><h3>Track Details</h3>'
    for r in [("Title",t['title']),("Artist",'<a href=/artist/{}>{}</a>'.format(t['artist_id'],t['an'])),("Year",t['release_year']),("Genre",t['genre'] or '—'),("Country",t['country'] or '—'),("Platform",t['platform'] or '—'),("Label",t['label'] or '—'),("ISRC",t['isrc'] or '—'),("Confidence",bl(t['confidence_level'])+' ('+str(t['confidence_score'])+')'),("Source",src_link),("Credit Line",'<span style="direction:rtl;display:inline-block">{}</span>'.format(t['exact_credit'] or '—')),("Verification",t['verification_status'] or '—')]:
        html += info(r[0], r[1])
    html += '</div><div class=card><h3>Mustafa\'s Roles</h3>{}</div>'.format(rpills)
    html += '<div class=card><h3>Collaborators ({})</h3><div class=table-wrap><table><tr><th>Name</th><th>Role</th></tr>{}</table></div></div>'.format(len(collabs), crows)
    html += '<div class=card><h3>Legal</h3>'+info("Copyright Owner",t['copyright_owner'] or '—')+info("Master Owner",t['master_owner'] or '—')+info("Publisher",t['publisher'] or '—')+info("Contract Status",t['contract_status'] or '—')+'</div>'
    return page(t['title'], "by {} ({})".format(t['an'], t['release_year']), html, "credits")

@app.route("/artist/<int:id>")
def artist_detail(id):
    a = q1("SELECT * FROM artists WHERE id=?", (id,))
    if not a: return "Not found", 404
    t = query("SELECT * FROM tracks WHERE artist_id=? AND is_active=1 ORDER BY release_year DESC", (id,))
    rows = ''.join('<tr><td><a href=/track/{}>{}</a></td><td>{}</td><td>{}{}</td></tr>'.format(x['id'],x['title'][:50],x['release_year'],rp(x,'role_mixing','M','mix'),rp(x,'role_mastering','Mst','master')) for x in t)
    html = '<div class=card><h3>{}</h3>'.format(a['name'])+'<div class=info-row><div class=info-label>Arabic Name</div><div class=info-value>{}</div></div><div class=info-row><div class=info-label>Country</div><div class=info-value>{}</div></div><div class=info-row><div class=info-label>Tracks</div><div class=info-value>{}</div></div></div>'.format(a['name_arabic'] or '—',a['country'] or '—',len(t))
    html += '<div class=card><h3>Tracks</h3><div class=table-wrap><table><tr><th>Track</th><th>Year</th><th>Roles</th></tr>{}</table></div></div>'.format(rows)
    return page(a['name'], "Artist — {} tracks".format(len(t)), html, "artists")

@app.route("/albums")
def albums():
    a = query("SELECT t.label as name, COUNT(*) as cnt, GROUP_CONCAT(DISTINCT a.name) as arts FROM tracks t JOIN artists a ON t.artist_id=a.id WHERE t.is_active=1 AND t.label IS NOT NULL AND t.label!='' GROUP BY t.label ORDER BY cnt DESC")
    rows = ''.join('<tr><td>{}</td><td>{}</td><td>{}</td></tr>'.format(x['name'],x['cnt'],x['arts']) for x in a) or '<tr><td colspan=3 style=color:var(--text2)>No labels yet</td></tr>'
    return page("Albums & Labels", "{} labels".format(len(a)), '<div class=card><div class=table-wrap><table><tr><th>Label</th><th>Tracks</th><th>Artists</th></tr>{}</table></div></div>'.format(rows), "albums")

@app.route("/credits")
def credits():
    t = query("SELECT t.*, a.name as an FROM tracks t JOIN artists a ON t.artist_id=a.id WHERE t.is_active=1 ORDER BY t.release_year DESC, a.name")
    rows = ''.join('<tr><td><a href=/track/{}>{}</a></td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>'.format(x['id'],x['title'][:50],x['an'],x['release_year'],' '.join(['Mix' if x['role_mixing'] else '','Master' if x['role_mastering'] else '','Arrange' if x['role_arranging'] else '','Compose' if x['role_composing'] else '','Produce' if x['role_producing'] else '']),x['platform'] or '—') for x in t)
    return page("All Credits", "{} total".format(len(t)), '<div class=card><div class=table-wrap><table><tr><th>Credit</th><th>Artist</th><th>Year</th><th>Role</th><th>Source</th></tr>{}</table></div></div>'.format(rows), "credits")

@app.route("/search")
def search():
    q = request.args.get("q", "")
    results = []
    if q:
        p = '%{}%'.format(q)
        results = query("SELECT t.*, a.name as an FROM tracks t JOIN artists a ON t.artist_id=a.id WHERE t.is_active=1 AND (t.title LIKE ? OR a.name LIKE ? OR t.genre LIKE ? OR t.platform LIKE ? OR t.country LIKE ? OR t.exact_credit LIKE ? OR t.label LIKE ? OR t.isrc LIKE ?) ORDER BY t.release_year DESC LIMIT 100", [p]*8)
    rrows = ''.join('<tr><td><a href=/track/{}>{}</a></td><td>{}</td><td>{}</td><td>{}{}{}</td><td>{}</td></tr>'.format(x['id'],x['title'][:50],x['an'],x['release_year'],rp(x,'role_mixing','Mix','mix'),rp(x,'role_mastering','Master','master'),rp(x,'role_arranging','Arrange','arrange'),bl(x['confidence_level'])) for x in results) if results else '<tr><td colspan=5 style=color:var(--text2)>No results</td></tr>'
    res_section = '<div class=card><h3>Results for &quot;{}&quot; ({})</h3><div class=table-wrap><table><tr><th>Track</th><th>Artist</th><th>Year</th><th>Roles</th><th>Confidence</th></tr>{}</table></div></div>'.format(q, len(results), rrows) if q else ''
    html = '<form method=GET action=/search><div class=search-box><input type=text name=q placeholder="Search artists, tracks, genres, credits…" value="{}"><button type=submit>🔍 Search</button></div></form>{}'.format(q, res_section)
    return page("Advanced Search", "Search by artist, track, year, role, platform, ISRC, keyword", html, "search")

@app.route("/statistics")
def statistics():
    s = q1("SELECT COUNT(*) as total, SUM(role_mixing) as mix, SUM(role_mastering) as master, SUM(role_arranging) as arrange, SUM(role_composing) as compose, SUM(role_producing) as produce, SUM(role_sound_engineer) as sound, SUM(role_executive_prod) as exec_p, COUNT(DISTINCT artist_id) as artists, MIN(release_year) as yr_min, MAX(release_year) as yr_max FROM tracks WHERE is_active=1")
    years = query("SELECT release_year, COUNT(*) as cnt FROM tracks WHERE is_active=1 GROUP BY release_year ORDER BY release_year")
    plats = query("SELECT platform, COUNT(*) as cnt FROM tracks WHERE is_active=1 AND platform IS NOT NULL GROUP BY platform ORDER BY cnt DESC")
    sgrid = '<div class=stat-grid>'+''.join('<div class=stat-card><div class=value>{}</div><div class=label>{}</div></div>'.format(str(s[k]),l) for l,k in [("Total","total"),("Mixing","mix"),("Mastering","master"),("Arranging","arrange"),("Composing","compose"),("Producing","produce"),("Artists","artists"),("Years","yr_min")])
    sgrid = sgrid.replace(str(s['yr_min']), '{}-{}'.format(s['yr_min'], s['yr_max']))+'</div>'
    yhtml = ''.join('<div style="display:flex;justify-content:space-between;padding:4px 0;font-size:13px;border-bottom:1px solid var(--border)"><span>{}</span><span style=color:var(--accent)>{} credits</span></div>'.format(y['release_year'],y['cnt']) for y in years)
    phtml = ''.join('<div style="display:flex;justify-content:space-between;padding:4px 0;font-size:13px;border-bottom:1px solid var(--border)"><span>{}</span><span style=color:var(--accent)>{}</span></div>'.format(p['platform'],p['cnt']) for p in plats)
    html = sgrid + '<div class=two-col><div class=card><h3>By Year</h3>{}</div><div class=card><h3>By Platform</h3>{}</div></div>'.format(yhtml, phtml)
    return page("Statistics", "Credits analytics", html, "statistics")

@app.route("/verification")
def verification():
    uv = query("SELECT t.*, a.name as an FROM tracks t JOIN artists a ON t.artist_id=a.id WHERE t.is_active=1 AND t.confidence_level!='Verified' ORDER BY t.confidence_score ASC")
    v = query("SELECT t.*, a.name as an FROM tracks t JOIN artists a ON t.artist_id=a.id WHERE t.is_active=1 AND t.confidence_level='Verified' ORDER BY t.release_year DESC")
    urows = ''.join('<tr><td><a href=/track/{}>{}</a></td><td>{}</td><td>{}</td><td>{}</td></tr>'.format(x['id'],x['title'][:50],x['an'],x['confidence_score'],bl(x['confidence_level'])) for x in uv) or '<tr><td colspan=4 style=color:var(--green)>✅ All verified!</td></tr>'
    vrows = ''.join('<tr><td><a href=/track/{}>{}</a></td><td>{}</td><td>{}</td></tr>'.format(x['id'],x['title'][:50],x['an'],x['release_year']) for x in v)
    html = '<div class=card><h3>Unverified / Pending ({})</h3><div class=table-wrap><table><tr><th>Track</th><th>Artist</th><th>Score</th><th>Level</th></tr>{}</table></div></div><div class=card><h3>Verified ({})</h3><div class=table-wrap><table><tr><th>Track</th><th>Artist</th><th>Year</th></tr>{}</table></div></div>'.format(len(uv), urows, len(v), vrows)
    return page("Verification Queue", "{} verified, {} pending".format(len(v), len(uv)), html, "verification")

@app.route("/legal")
def legal():
    t = query("SELECT t.*, a.name as an FROM tracks t JOIN artists a ON t.artist_id=a.id WHERE t.is_active=1 ORDER BY t.release_year DESC")
    rows = ''.join('<tr><td><a href=/track/{}>{}</a></td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>'.format(x['id'],x['title'][:40],x['an'],x['copyright_owner'] or '—',x['master_owner'] or '—',x['publisher'] or '—',x['contract_status'] or '—') for x in t)
    return page("Legal Review", "Copyright, ownership, and rights tracking", '<div class=card><div class=table-wrap><table><tr><th>Track</th><th>Artist</th><th>Copyright Owner</th><th>Master Owner</th><th>Publisher</th><th>Contract</th></tr>{}</table></div></div>'.format(rows), "legal")

@app.route("/royalties")
def royalties():
    t = query("SELECT t.*, a.name as an FROM tracks t JOIN artists a ON t.artist_id=a.id WHERE t.is_active=1 ORDER BY t.release_year DESC")
    rows = ''.join('<tr><td><a href=/track/{}>{}</a></td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>'.format(x['id'],x['title'][:40],x['an'],x['release_year'],' '.join(['Mix' if x['role_mixing'] else '','Master' if x['role_mastering'] else '','Compose' if x['role_composing'] else '','Produce' if x['role_producing'] else '']),x['publisher'] or '—',x['royalty_notes'] or 'Unregistered') for x in t)
    return page("Royalty Opportunities", "Revenue tracking", '<div class=card><div class=table-wrap><table><tr><th>Track</th><th>Artist</th><th>Year</th><th>Mustafa Role</th><th>Publisher</th><th>Royalty Notes</th></tr>{}</table></div></div>'.format(rows), "royalties")

@app.route("/evidence")
def evidence():
    evdir = os.path.join(BASE, "evidence")
    items = []
    if os.path.exists(evdir):
        for folder in sorted(os.listdir(evdir)):
            fpath = os.path.join(evdir, folder)
            if os.path.isdir(fpath):
                files = os.listdir(fpath)
                items.append({"folder": folder, "files": files, "count": len(files)})
    rows = ''.join('<tr><td>{}</td><td>{} files: {}</td></tr>'.format(i['folder'], i['count'], ', '.join(i['files'][:5]) + ('…' if i['count']>5 else '')) for i in items) or '<tr><td colspan=2 style=color:var(--text2)>No evidence folders yet</td></tr>'
    return page("Evidence", "{} work folders".format(len(items)), '<div class=card><div class=table-wrap><table><tr><th>Work Folder</th><th>Files</th></tr>{}</table></div></div>'.format(rows), "evidence")

@app.route("/reports")
def reports():
    r = query("SELECT * FROM reports ORDER BY created_at DESC")
    rows = ''.join('<tr><td>{}</td><td>{}</td><td>{}</td></tr>'.format(x['report_type'],x['title'],x['created_at']) for x in r) or '<tr><td colspan=3 style=color:var(--text2)>No reports yet</td></tr>'
    return page("Reports", "{} reports".format(len(r)), '<div class=card><div class=table-wrap><table><tr><th>Type</th><th>Title</th><th>Date</th></tr>{}</table></div></div>'.format(rows), "reports")

@app.route("/settings")
def settings():
    dbc = q1("SELECT COUNT(*) as c FROM sqlite_master WHERE type='table'")['c']
    tc = q1("SELECT COUNT(*) as c FROM tracks")['c']
    bc = q1("SELECT COUNT(*) as c FROM backups")['c']
    html = '<div class=stat-grid><div class=stat-card><div class=value>{}</div><div class=label>DB Tables</div></div><div class=stat-card><div class=value>{}</div><div class=label>Total Tracks</div></div><div class=stat-card><div class=value>{}</div><div class=label>Backups</div></div><div class=stat-card><div class=value>SQLite</div><div class=label>Engine</div></div></div>'.format(dbc, tc, bc)
    html += '<div class=card><h3>System Info</h3><div class=info-row><div class=info-label>Database Path</div><div class=info-value>{}</div></div><div class=info-row><div class=info-label>Evidence Dir</div><div class=info-value>{}</div></div><div class=info-row><div class=info-label>Backups Dir</div><div class=info-value>{}</div></div><div class=info-row><div class=info-label>Git Repo</div><div class=info-value>Initialized (master)</div></div><div class=info-row><div class=info-label>API Connectors</div><div class=info-value>Spotify · YouTube · Discogs · MusicBrainz · Apple Music · Jaxsta</div></div><div class=info-row><div class=info-label>JSON Backup</div><div class=info-value>Active — exports to /exports/</div></div></div>'.format(DB_PATH, os.path.join(BASE, 'evidence'), os.path.join(BASE, 'backups'))
    return page("Settings", "System configuration", html, "settings")

if __name__ == "__main__":
    cnt = q1("SELECT COUNT(*) as c FROM tracks WHERE is_active=1")['c']
    port = int(os.environ.get("PORT", 5000))
    print("="*50)
    print("MUSTAFA MIXING Dashboard v2.0")
    print("="*50)
    print("URL: http://0.0.0.0:{}".format(port))
    print("DB: {}".format(DB_PATH))
    print("Credits: {} active".format(cnt))
    print("="*50)
    app.run(host="0.0.0.0", port=port)
